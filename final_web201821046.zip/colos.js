//데이터 참고용

colosseum[0] = ["천하제일 얼굴 인식대회","2022.04.01","2022.05.01","celebA"];
colosseum[1] = ["도로위 인식의 최강자 선발 대회","2022.06.01","2022.07.01","kitti"];
colosseum[2] = ["Did you understand what I said?","2022.08.01","2022.09.01","wmt19"];

