function share1(){
 document.getElementById("hidden_text").style.visibility ="visible";
 document.getElementById("hidden_img").style.visibility ="hidden";
 document.getElementById("hidden_vi").style.visibility ="hidden";
 document.getElementById("hidden_wav").style.visibility ="hidden";
    
}

function share2(){
    document.getElementById("hidden_text").style.visibility ="hidden";
    document.getElementById("hidden_img").style.visibility ="visible";
    document.getElementById("hidden_vi").style.visibility ="hidden";
    document.getElementById("hidden_wav").style.visibility ="hidden";
       
   }

function share3(){
    document.getElementById("hidden_text").style.visibility ="hidden";
    document.getElementById("hidden_img").style.visibility ="hidden";
    document.getElementById("hidden_vi").style.visibility ="visible";
    document.getElementById("hidden_wav").style.visibility ="hidden";
       
   }

function share4(){
    document.getElementById("hidden_text").style.visibility ="hidden";
    document.getElementById("hidden_img").style.visibility ="hidden";
    document.getElementById("hidden_vi").style.visibility ="hidden";
    document.getElementById("hidden_wav").style.visibility ="visible";
       
   }