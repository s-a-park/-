var cmu = new Object();
cmu.id="CMU";
cmu.link="http://domedb.perception.cs.cmu.edu/";
cmu.cate="Image";
cmu.instance="-";
cmu.task="-";
cmu.desc="-";
cmu.tuto="-";

var human = new Object();
human.id="Human 3.6M";
human.link="http://vision.imar.ro/human3.6m/description.php";
human.cate="Image";
human.instance="-";
human.task="3D_Human_Pose_Estimation,3D_Absolute_Human_Pose_Estimation,Human_action_generation";
human.desc="The Human3.6M dataset is one of the largest motion capture datasets, which consists of 3.6 million human poses and corresponding images captured by a high-speed motion capture system. There are 4 high-resolution progressive scan cameras to acquire video ...";

var apo = new Object();
apo.id="ApoloScape";
apo.link="http://apolloscape.auto/";
apo.cate="Image";
apo.instance="-";
apo.task="-";
apo.desc="-";
apo.tuto="https://capsulesbot.com/blog/2018/08/24/apolloscape-posenet-pytorch.html";

var c10 = new Object();
c10.id="Cifar-10";
c10.link="https://www.cs.toronto.edu/~kriz/cifar.html";
c10.cate="Image";
c10.instance="60000";
c10.task="Image_Classification,Image_Generation,Graph_Classification";
c10.desc="The CIFAR-10 dataset (Canadian Institute for Advanced Research, 10 classes) is a subset of the Tiny Images dataset and consists of 60000 32x32 color images. The images are labelled with one of 10 mutually exclusive classes: airplane, automobile (but not ...";
c10.tuto="https://ermlab.com/en/blog/nlp/cifar-10-classification-using-keras-tutorial/";

var c100 = new Object();
c100.id="Cifar-100";
c100.link="http://domedb.perception.cs.cmu.edu/";
c100.cate="Image";
c100.instance="60000";
c100.task="Image_Classification,Image_Generation,Few-Shot_Image_Classification";
c100.desc="The CIFAR-10 dataset (Canadian Institute for Advanced Research, 10 classes) is a subset of the Tiny Images dataset and consists of 60000 32x32 color images. The images are labelled with one of 10 mutually exclusive classes: airplane, automobile (but not ...";
c100.tuto="-";

var om = new Object();
om.id="Omniglot";
om.link="https://github.com/brendenlake/omniglot#python";
om.cate="Image";
om.instance="38300";
om.task="Few-Shot_Image_Classification,Density_Estimation,Multi-Task_Learning";
om.desc="Omniglot is a large dataset of hand-written characters with 1623 characters and 20 examples for each character. These characters are collected based upon 50 alphabets from different countries. It contains both images and strokes data. Stroke data are coo...";
om.tuto="https://towardsdatascience.com/few-shot-learning-with-prototypical-networks-87949de03ccd";

var mn = new Object();
mn.id="Mnist";
mn.link="http://yann.lecun.com/exdb/mnist/";
mn.cate="Image";
mn.instance="60000";
mn.task="Image_Classification,Image_Generation,Domain_Adaptation";
mn.desc="The MNIST database (Modified National Institute of Standards and Technology database) is a large collection of handwritten digits. It has a training set of 60,000 examples, and a test set of 10,000 examples. It is a subset of a larger NIST Special Databa...";
mn.tuto="https://towardsdatascience.com/image-classification-in-10-minutes-with-mnist-dataset-54c35b77a38d";

var ce = new Object();
ce.id="CelebA";
ce.link="http://mmlab.ie.cuhk.edu.hk/projects/CelebA.html";
ce.cate="Image";
ce.instance="-";
ce.task="Image_Classification,Image_Generation,Face_Alignment";
ce.desc="CelebFaces Attributes dataset contains 202,599 face images of the size 178×218 from 10,177 celebrities, each annotated with 40 binary labels indicating facial attributes like hair color, gender and age.";
ce.tuto="-";

var sv = new Object();
sv.id="SVHN";
sv.link="http://ufldl.stanford.edu/housenumbers/";
sv.cate="Image";
sv.instance="-";
sv.task="Image_Classification,Domain_Adaption,Semi-Supervised_Image_Classification";
sv.desc="The Street View House Number (SVHN) is a digit classification benchmark dataset that contains 600000 32×32 RGB images of printed digits (from 0 to 9) cropped from pictures of house number plates. The cropped images are centered in the digit of interest,...";
sv.tuto="-";

var st = new Object();
st.id="Street Style dataset of Matzen";
st.link="http://streetstyle.cs.cornell.edu/";
st.cate="Image";
st.instance="-";
st.task="-";
st.desc="-";
st.tuto="-";

var pk = new Object();
pk.id="PKU VehicleID (VehicleID)";
pk.link="https://pkuml.org/resources/pku-vehicleid.html";
pk.cate="Image";
pk.instance="-";
pk.task="Vehicle_Re-Identification";
pk.desc="The “VehicleID” dataset contains CARS captured during the daytime by multiple real-world surveillance cameras distributed in a small city in China. There are 26,267 vehicles (221,763 images in total) in the entire dataset. Each image is attached with...";
pk.tuto="-";

var the = new Object();
the.id="The In-shop Clothes";
the.link="http://mmlab.ie.cuhk.edu.hk/projects/DeepFashion/InShopRetrieval.html";
the.cate="Image";
the.instance="-";
the.task="-";
the.desc="-";
the.tuto="-";

var ta = new Object();
ta.id="Taskonomy";
ta.link="http://taskonomy.stanford.edu/";
ta.cate="Image";
ta.instance="-";
ta.task="Depth_Estimation,Surface_Normals_Estimation";
ta.desc="Taskonomy provides a large and high-quality dataset of varied indoor scenes. ???Complete pixel-level geometric information via aligned meshes. ?Semantic information via knowledge distillation from ImageNet, MS COCO, and MIT Places. ?Globally consistent c...";
ta.tuto="-";


function align(){
    var align = document.getElementsByClassName("wiki_dt");
    align.sort();     //이름순, 카테고리, 목적, 튜토리얼 유무로 정렬
}

function change1(){
var name= document.getElementById("data_name");
name.innerText=cmu.id;

var a = document.getElementById("data1");
a.innerText=cmu.cate;

var b = document.getElementById("data2");
b.innerText=cmu.instance;

var c = document.getElementById("data3");
c.innerText=cmu.task;

var d = document.getElementById("data4");
d.innerText=cmu.desc;

var e = document.getElementById("link");
e.href=cmu.link;

var f = document.getElementById("link_tuto");
f.href = cmu.tuto;

}

function change2(){
var name= document.getElementById("data_name");
name.innerText=human.id;

var a = document.getElementById("data1");
a.innerText=human.cate;

var b = document.getElementById("data2");
b.innerText=human.instance;

var c = document.getElementById("data3");
c.innerText=human.task;

var d = document.getElementById("data4");
d.innerText=human.desc;

var e = document.getElementById("link");
e.href=human.link;

var f = document.getElementById("link_tuto");
f.href = human.tuto;

}

function change3(){
var name= document.getElementById("data_name");
name.innerText=apo.id;

var a = document.getElementById("data1");
a.innerText=apo.cate;

var b = document.getElementById("data2");
b.innerText=apo.instance;

var c = document.getElementById("data3");
c.innerText=apo.task;

var d = document.getElementById("data4");
d.innerText=apo.desc;

var e = document.getElementById("link");
e.href=apo.link;

var f = document.getElementById("link_tuto");
f.href = apo.tuto;

}

function change4(){
var name= document.getElementById("data_name");
name.innerText=c10.id;

var a = document.getElementById("data1");
a.innerText=c10.cate;

var b = document.getElementById("data2");
b.innerText=c10.instance;

var c = document.getElementById("data3");
c.innerText=c10.task;

var d = document.getElementById("data4");
d.innerText=c10.desc;

var e = document.getElementById("link");
e.href=c10.link;

var f = document.getElementById("link_tuto");
f.href = c10.tuto;

}

function change5(){
var name= document.getElementById("data_name");
name.innerText=c100.id;

var a = document.getElementById("data1");
a.innerText=c100.cate;

var b = document.getElementById("data2");
b.innerText=c100.instance;

var c = document.getElementById("data3");
c.innerText=c100.task;

var d = document.getElementById("data4");
d.innerText=c100.desc;

var e = document.getElementById("link");
e.href=c100.link;

var f = document.getElementById("link_tuto");
f.href = c100.tuto;

}

function change6(){
var name= document.getElementById("data_name");
name.innerText=om.id;

var a = document.getElementById("data1");
a.innerText=om.cate;

var b = document.getElementById("data2");
b.innerText=om.instance;

var c = document.getElementById("data3");
c.innerText=om.task;

var d = document.getElementById("data4");
d.innerText=om.desc;

var e = document.getElementById("link");
e.href=om.link;

var f = document.getElementById("link_tuto");
f.href = om.tuto;

}

function change7(){
var name= document.getElementById("data_name");
name.innerText=mn.id;

var a = document.getElementById("data1");
a.innerText=mn.cate;

var b = document.getElementById("data2");
b.innerText=mn.instance;

var c = document.getElementById("data3");
c.innerText=mn.task;

var d = document.getElementById("data4");
d.innerText=mn.desc;

var e = document.getElementById("link");
e.href=mn.link;

var f = document.getElementById("link_tuto");
f.href = mn.tuto;

}

function change8(){
var name= document.getElementById("data_name");
name.innerText=ce.id;

var a = document.getElementById("data1");
a.innerText=ce.cate;

var b = document.getElementById("data2");
b.innerText=ce.instance;

var c = document.getElementById("data3");
c.innerText=ce.task;

var d = document.getElementById("data4");
d.innerText=ce.desc;

var e = document.getElementById("link");
e.href=ce.link;

var f = document.getElementById("link_tuto");
f.href = ce.tuto;

}

function change9(){
var name= document.getElementById("data_name");
name.innerText = sv.id;

var a = document.getElementById("data1");
a.innerText = sv.cate;

var b = document.getElementById("data2");
b.innerText = sv.instance;

var c = document.getElementById("data3");
c.innerText = sv.task;

var d = document.getElementById("data4");
d.innerText = sv.desc;

var e = document.getElementById("link");
e.href = sv.link;

var f = document.getElementById("link_tuto");
f.href = sv.tuto;

}

function change10(){
var name= document.getElementById("data_name");
name.innerText=st.id;

var a = document.getElementById("data1");
a.innerText=st.cate;

var b = document.getElementById("data2");
b.innerText=st.instance;

var c = document.getElementById("data3");
c.innerText=st.task;

var d = document.getElementById("data4");
d.innerText=st.desc;

var e = document.getElementById("link");
e.href=st.link;

var f = document.getElementById("link_tuto");
f.href = st.tuto;

}

function change11(){
var name= document.getElementById("data_name");
name.innerText=pk.id;

var a = document.getElementById("data1");
a.innerText=pk.cate;

var b = document.getElementById("data2");
b.innerText=pk.instance;

var c = document.getElementById("data3");
c.innerText=pk.task;

var d = document.getElementById("data4");
d.innerText=pk.desc;

var e = document.getElementById("link");
e.href=pk.link;

var f = document.getElementById("link_tuto");
f.href = pk.tuto;

}

function change12(){
var name= document.getElementById("data_name");
name.innerText=the.id;

var a = document.getElementById("data1");
a.innerText=the.cate;

var b = document.getElementById("data2");
b.innerText=the.instance;

var c = document.getElementById("data3");
c.innerText=the.task;

var d = document.getElementById("data4");
d.innerText=the.desc;

var e = document.getElementById("link");
e.href=the.link;

var f = document.getElementById("link_tuto");
f.href = the.tuto;

}

function change13(){
var name= document.getElementById("data_name");
name.innerText=ta.id;

var a = document.getElementById("data1");
a.innerText=ta.cate;

var b = document.getElementById("data2");
b.innerText=ta.instance;

var c = document.getElementById("data3");
c.innerText=ta.task;

var d = document.getElementById("data4");
d.innerText=ta.desc;

var e = document.getElementById("link");
e.href=ta.link;

var f = document.getElementById("link_tuto");
f.href = ta.tuto;

}